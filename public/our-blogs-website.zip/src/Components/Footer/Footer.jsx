import './Footer.css'
function Footer() {
    return (
        <div className='footer-div'>
            <h1>Developed by Jashwanth</h1>
        </div>
    )
}
export default Footer;